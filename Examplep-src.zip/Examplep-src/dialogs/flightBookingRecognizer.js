// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT License.

const { LuisRecognizer } = require('botbuilder-ai');

class FlightBookingRecognizer {
    constructor(config) {
        const luisIsConfigured = config && config.applicationId && config.endpointKey && config.endpoint;
        if (luisIsConfigured) {
	console.log("FlightBookingRecognizer constructor");
            // Set the recognizer options depending on which endpoint version you want to use e.g v2 or v3.
            // More details can be found in https://docs.microsoft.com/en-gb/azure/cognitive-services/luis/luis-migration-api-v3
            const recognizerOptions = {
                apiVersion: 'v3'
            };

            this.recognizer = new LuisRecognizer(config, recognizerOptions);
        }
    }

    get isConfigured() {
        return (this.recognizer !== undefined);
    }

    /**
     * Returns an object with preformatted LUIS results for the bot's dialogs to consume.
     * @param {TurnContext} context
     */
    async executeLuisQuery(context) {
		console.log("FlightBookingRecognizer constructor--------execute Luis Query");
        return await this.recognizer.recognize(context);
    }

    getFromEntities(result) {
	//console.log("from-Result:  "+ result);
       // let fromValue, fromAirportValue;
     // let Month;

let from;
console.log("From Instance:   ", result.entities.$instance);

console.log("from Entitiy:  ", result.entities);
        if (result.entities.From) {
	console.log("From:  ", result.entities.From);
            from = result.entities.From[0];
        }
       console.log("from"+ from);
 console.log();

        return {from: from};
    }

  getToEntities(result) {
       // let toValue, toAirportValue;
let to; 
       if (result.entities.To) {
            to= result.entities.To[0];
        }
      

        return { to: to };
    }

    /**
     * This value will be a TIMEX. And we are only interested in a Date so grab the first result and drop the Time part.
     * TIMEX is a format that represents DateTime expressions that include some ambiguity. e.g. missing a Year.
     */
/*    getTravelDate(result) {
        const datetimeEntity = result.entities.datetime;
        if (!datetimeEntity || !datetimeEntity[0]) return undefined;

        const timex = datetimeEntity[0].timex;
        if (!timex || !timex[0]) return undefined;

        const datetime = timex[0].split('T')[0];
        return datetime;
    }*/
}

module.exports.FlightBookingRecognizer = FlightBookingRecognizer;
