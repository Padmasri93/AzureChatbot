// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT License.

const { TimexProperty } = require('@microsoft/recognizers-text-data-types-timex-expression');
const { InputHints, MessageFactory } = require('botbuilder');
const { ConfirmPrompt, TextPrompt, WaterfallDialog } = require('botbuilder-dialogs');
const { CancelAndHelpDialog } = require('./cancelAndHelpDialog');
const { DateResolverDialog } = require('./dateResolverDialog');

const CONFIRM_PROMPT = 'confirmPrompt';
const DATE_RESOLVER_DIALOG = 'dateResolverDialog';
const TEXT_PROMPT = 'textPrompt';
const WATERFALL_DIALOG = 'waterfallDialog';

class BookingDialog extends CancelAndHelpDialog {
    constructor(id) {
        super(id || 'bookingDialog');

        this.addDialog(new TextPrompt(TEXT_PROMPT))
            .addDialog(new ConfirmPrompt(CONFIRM_PROMPT))
            .addDialog(new DateResolverDialog(DATE_RESOLVER_DIALOG))
            .addDialog(new WaterfallDialog(WATERFALL_DIALOG, [
                this.personName.bind(this),
                this.noOfPersons.bind(this),
                this.place.bind(this),
                this.bookingdateTime.bind(this),
                this.confirmStep.bind(this),
                this.finalStep.bind(this)
            ]));

        this.initialDialogId = WATERFALL_DIALOG;
    }

    /**
     * If a destination city has not been provided, prompt for one.
     */

    async personName(stepContext) {
        const bookingDetails = stepContext.options;

        if (!bookingDetails.BookingName) {
            const messageText = 'On whose name do you want to book a table ?';
            const msg = MessageFactory.text(messageText, messageText, InputHints.ExpectingInput);
            return await stepContext.prompt(TEXT_PROMPT, { prompt: msg });
        }
//console.log("bookingDetails Name 3: "+bookingDetails.BookingName);
        return await stepContext.next(bookingDetails.BookingName);
    }

async noOfPersons(stepContext) {
        const bookingDetails = stepContext.options;
          bookingDetails.BookingName=stepContext.result;
        if (!bookingDetails.NoOfPersons) {
            const messageText = 'For how many people ?';
            const msg = MessageFactory.text(messageText, messageText, InputHints.ExpectingInput);
            return await stepContext.prompt(TEXT_PROMPT, { prompt: msg });
        }
        return await stepContext.next(bookingDetails.NoOfPersons);
    }
async place(stepContext) {
        const bookingDetails = stepContext.options;
bookingDetails.NoOfPersons=stepContext.result;

        if (!bookingDetails.Branch) {
            const messageText = 'In Which branch you want to book a table ?';
            const msg = MessageFactory.text(messageText, messageText, InputHints.ExpectingInput);
            return await stepContext.prompt(TEXT_PROMPT, { prompt: msg });
        }
        return await stepContext.next(bookingDetails.Branch);
    }



   /**
     * If a travel date has not been provided, prompt for one.
     * This will use the DATE_RESOLVER_DIALOG.
     */
    async bookingdateTime(stepContext) {
        const bookingDetails = stepContext.options;

        // Capture the results of the previous step
     bookingDetails.Branch=stepContext.result;
        if (!bookingDetails.BookingDatetime || this.isAmbiguous(bookingDetails.BookingDatetime)) {
            return await stepContext.beginDialog(DATE_RESOLVER_DIALOG, { date: bookingDetails.BookingDatetime });
        }
        return await stepContext.next(bookingDetails.BookingDatetime);
    }

    /**
     * Confirm the information the user has provided.
     */
    async confirmStep(stepContext) {
        const bookingDetails = stepContext.options;

        // Capture the results of the previous step
        bookingDetails.BookingDatetime = stepContext.result;
     const messageText = `your booking details are: you have booked table in ${ bookingDetails.Branch } for ${ bookingDetails.NoOfPersons } persons on the name of ${ bookingDetails.BookingName } at ${ bookingDetails.BookingDatetime } is this correct`;
     const msg = MessageFactory.text(messageText, messageText, InputHints.ExpectingInput);

        // Offer a YES/NO prompt.
        return await stepContext.prompt(CONFIRM_PROMPT, { prompt: msg });
    }

    /**
     * Complete the interaction and end the dialog.
     */
    async finalStep(stepContext) {
	const bookingDetails = stepContext.options;
	 if (stepContext.result) {
             const messageText = `your booking details are: you have booked table in ${ bookingDetails.Branch } for ${ bookingDetails.NoOfPersons } persons on the name of ${ bookingDetails.BookingName } at ${ bookingDetails.BookingDatetime } is this correct`;
             const msg = MessageFactory.text(messageText, messageText, InputHints.ExpectingInput);
            return await stepContext.prompt(TEXT_PROMPT, { prompt: msg });
           
        }
       /* if (stepContext.result === true) {
            const bookingDetails = stepContext.options;
            return await stepContext.endDialog(bookingDetails);
        }*/
        return await stepContext.endDialog();
    }

    isAmbiguous(timex) {
        const timexPropery = new TimexProperty(timex);
        return !timexPropery.types.has('definite');
    }
}

module.exports.BookingDialog = BookingDialog;
