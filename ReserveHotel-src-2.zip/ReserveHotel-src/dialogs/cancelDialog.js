// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT License.

const { TimexProperty } = require('@microsoft/recognizers-text-data-types-timex-expression');
const { InputHints, MessageFactory } = require('botbuilder');
const { ConfirmPrompt, TextPrompt, WaterfallDialog } = require('botbuilder-dialogs');
const { CancelAndHelpDialog } = require('./cancelAndHelpDialog');
//const { DateResolverDialog } = require('./dateResolverDialog');

const CONFIRM_PROMPT = 'confirmPrompt';
//const DATE_RESOLVER_DIALOG = 'dateResolverDialog';
const TEXT_PROMPT = 'textPrompt';
const WATERFALL_DIALOG = 'waterfallDialog';

class CancelDialog extends CancelAndHelpDialog {
    constructor(id) {
        super(id || 'cancelDialog');

        this.addDialog(new TextPrompt(TEXT_PROMPT))
            .addDialog(new ConfirmPrompt(CONFIRM_PROMPT))
            .addDialog(new WaterfallDialog(WATERFALL_DIALOG, [
                this.getBookingNumber.bind(this),
                this.confirmStep.bind(this),
                this.finalStep.bind(this)
            ]));

        this.initialDialogId = WATERFALL_DIALOG;
    }

  
    async getBookingNumber(stepContext) {
        //const bookingDetails = stepContext.options;

      //  if (!bookingDetails.BookingName) {
            const messageText = 'Enter booking Number to cancel the reservation : ';
            const msg = MessageFactory.text(messageText, messageText, InputHints.ExpectingInput);
            return await stepContext.prompt(TEXT_PROMPT, { prompt: msg });
     }
    async confirmStep(stepContext) {
        const bookingNumber = stepContext.result;

        // Capture the results of the previous step
    //    bookingDetails.BookingDatetime = stepContext.result;
     const messageText = `Please confirm,your booking with the number ${ bookingNumber} is going to be cancelled....`;
     const msg = MessageFactory.text(messageText, messageText, InputHints.ExpectingInput);

        // Offer a YES/NO prompt.
        return await stepContext.prompt(CONFIRM_PROMPT, { prompt: msg });
    }
 async finalStep(stepContext) {
       if (stepContext.result) {   
    const messageText = `your booking cancelled Successfully ....`;
      const msg = MessageFactory.text(messageText, messageText, InputHints.ExpectingInput);
             await stepContext.prompt(TEXT_PROMPT, { prompt: msg });
    }
 return await stepContext.endDialog();
}

}

module.exports.CancelDialog = CancelDialog;
